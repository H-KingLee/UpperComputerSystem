﻿namespace UI.User
{
    partial class UserLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            tB_User = new TextBox();
            tB_Password = new TextBox();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.用户登录图标;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(395, 383);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("新宋体", 22.2F, FontStyle.Regular, GraphicsUnit.Point, 134);
            label1.Location = new Point(411, 8);
            label1.Name = "label1";
            label1.Size = new Size(112, 37);
            label1.TabIndex = 1;
            label1.Text = "Login";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("新宋体", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 134);
            label2.Location = new Point(427, 152);
            label2.Name = "label2";
            label2.Size = new Size(58, 23);
            label2.TabIndex = 2;
            label2.Text = "User";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("新宋体", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 134);
            label3.Location = new Point(427, 207);
            label3.Name = "label3";
            label3.Size = new Size(106, 23);
            label3.TabIndex = 3;
            label3.Text = "Password";
            // 
            // tB_User
            // 
            tB_User.Location = new Point(539, 150);
            tB_User.Name = "tB_User";
            tB_User.Size = new Size(197, 27);
            tB_User.TabIndex = 4;
            tB_User.Text = "admin";
            // 
            // tB_Password
            // 
            tB_Password.Location = new Point(539, 205);
            tB_Password.Name = "tB_Password";
            tB_Password.PasswordChar = '*';
            tB_Password.Size = new Size(197, 27);
            tB_Password.TabIndex = 5;
            tB_Password.Text = "123456";
            // 
            // button1
            // 
            button1.BackColor = Color.Chartreuse;
            button1.Location = new Point(521, 312);
            button1.Name = "button1";
            button1.Size = new Size(125, 44);
            button1.TabIndex = 6;
            button1.Text = "Login";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // UserLogin
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(771, 384);
            Controls.Add(button1);
            Controls.Add(tB_Password);
            Controls.Add(tB_User);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "UserLogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "用户登录";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox tB_User;
        private TextBox tB_Password;
        private Button button1;
    }
}
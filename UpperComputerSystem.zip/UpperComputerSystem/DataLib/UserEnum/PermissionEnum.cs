﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLib.UserEnum
{
    /// <summary>
    /// 权限枚举
    /// </summary>
    [Description("权限枚举")]
    public enum PermissionEnum
    {
        None = 0,
        [Description("编辑")]
        Edit = 1,
        [Description("操作")]
        Operation = 2,
        [Description("查看")]
        ReadOnly = 3
        //[Description("创建")]
        //Create = 4,
        //[Description("删除")]
        //Delete = 5,
        //[Description("导出")]
        //Export = 6

    }
}

﻿namespace CommunicationDriver
{
    internal class Siemens
    {
    }
}

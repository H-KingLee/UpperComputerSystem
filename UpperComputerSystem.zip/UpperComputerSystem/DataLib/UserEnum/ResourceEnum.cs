﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLib.User
{
    /// <summary>
    /// 资源枚举
    /// </summary>
    [Description("资源枚举")]
    public enum ResourceEnum
    {
        None = 0,
        [Description("全部界面")]
        UI_All = 1,
        [Description("操作界面")]
        UI_Operation = 2,
        [Description("演示界面")]
        UI_Presentationa = 3
        //[Description("曲线界面")]
        //UI_TrendLine = 4,
        //[Description("设置界面")]
        //UI_Set = 5,
        //[Description("用户界面")]
        //UI_User = 6
    }
}

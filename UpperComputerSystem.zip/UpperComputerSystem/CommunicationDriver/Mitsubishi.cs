﻿namespace CommunicationDriver
{
    internal class Mitsubishi
    {
    }
}

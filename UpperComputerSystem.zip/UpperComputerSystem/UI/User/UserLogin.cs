﻿using DataLib;
using DataLib.UserEnum;
using logMessageclass;
using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using UI.Properties;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
namespace UI.User
{
    public partial class UserLogin : Form
    {
        public static string UserName { get; set; }    // ⽤⼾,使⽤系统的⼈
        public string Password { get; set; }   // 密码
        public static  RoleEnum Role {  get; set; }   // ⻆⾊,⾝份或职责
        public static  PermissionEnum Permission {  get; set; }// 权限,权限定义了“对资源可以执⾏什么操作”，常⻅操作包括：
                                               // 查看（Read）创建（Create）编辑（Edit / Update）删除（Delete）审批、导出、打印等系统⾃定义操作

        public UserLogin()
        {
            InitializeComponent();
            InitialUi();
            SQLUser.CreateTables();
            //CreateTables();
        }
        private void InitialUi()
        {
            tB_User.Text = string.Empty;
            tB_Password.Text = string.Empty;
            this.StartPosition = FormStartPosition.CenterParent;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            UserName= tB_User.Text.Trim();
            this.Password= tB_Password.Text.Trim();
            string errorMsg = string.Empty;
            RoleEnum _Role;
            PermissionEnum _Permission;
            if(tB_User.Text.Trim()!="")
            {
                if (SQLUser.VerifyUser(UserName, Password, out _Role, out _Permission, out  errorMsg))
                {
                    Role = _Role;
                    Permission = _Permission;
                    this.DialogResult = DialogResult.OK;
                    //MessageBox.Show($"登录成功:{errorMsg}");
                    string Userinfo = $"\n用户名：{UserName}\n" + $"⻆⾊：{Role}\n" + $"权限：{Permission}";
                APPmessage.ShowSuccess($"登录成功{Userinfo}");
                logMessage.Message($"登录成功！用户名：{UserName}");
                }
                else
                {
                    APPmessage.ShowOperationResult(false, $"登录失败:{errorMsg}");
                    //MessageBox.Show($"登录失败:{errorMsg}");

                }
            }
            else
            {
                errorMsg = "用户名不能为空！";
                APPmessage.ShowOperationResult(false, $"登录失败:{errorMsg}");

                //MessageBox.Show($"登录失败:{errorMsg}");
            }
        }

    }
}

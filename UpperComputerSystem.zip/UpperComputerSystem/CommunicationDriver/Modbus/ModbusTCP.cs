﻿namespace CommunicationDriver.Modbus
{
    internal class ModbusTCP
    {
    }
}

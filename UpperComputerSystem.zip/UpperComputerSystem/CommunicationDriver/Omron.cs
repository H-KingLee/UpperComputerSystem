﻿namespace CommunicationDriver
{
    internal class Omron
    {
    }
}

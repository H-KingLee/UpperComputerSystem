﻿namespace UI
{
    public class APPmessage
    {
        public static void ShowSuccess(string message)
        {
            MessageBox.Show(message, $"成功",
            MessageBoxButtons.OK, MessageBoxIcon.None);
        }
        public static void ShowWarning(string message)
        {
            MessageBox.Show(message, $"警告",
            MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        public static bool AskYesNo(string question)
        {
            return MessageBox.Show(question, $"确认",
             MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;
        }
        public static DialogResult AskYesNoCancel(string question)
        {
            return MessageBox.Show(question, $"选择",
             MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question,
             MessageBoxDefaultButton.Button3); // 默认选择"取消"
        }

        public static bool ConfirmDelete(string itemName)
        {
            return MessageBox.Show(
            $"确定要删除 '{itemName}' 吗？\n此操作无法撤销！",
            "删除确认",
             MessageBoxButtons.YesNo,
             MessageBoxIcon.Warning,
             MessageBoxDefaultButton.Button2
             ) == DialogResult.Yes;
        }

        public static void ShowOperationResult(bool success, string operation)
        {
            if (success)
            {
                MessageBox.Show($"{operation}成功完成！", "操作成功",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show($"{operation}失败，请重试。", "操作失败",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public static void ShowError(Exception ex, string context = "")
        {
            string errorMessage = string.IsNullOrEmpty(context)
             ? $"发生错误: {ex.Message}"
             : $"在{context}时发生错误: {ex.Message}";
            MessageBox.Show(
            errorMessage,
           "系统错误",
            MessageBoxButtons.OK,
            MessageBoxIcon.Error,
            MessageBoxDefaultButton.Button1
            );
        }
        public static bool ConfirmDangerousAction(string actionName, string details = "")
        {
            string message = string.IsNullOrEmpty(details)
             ? $"确定要{actionName}吗？此操作无法撤销！"
             : $"确定要{actionName}吗？\n\n详细信息：{details}\n\n此操作无法撤销！";
            DialogResult result = MessageBox.Show(
            message,
           "操作确认",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning,
            MessageBoxDefaultButton.Button2 // 默认选中"否"，更安全
            );
            return result == DialogResult.Yes;
        }
    }
}

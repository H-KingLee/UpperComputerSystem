﻿namespace CommunicationDriver
{
    internal class OPCUA
    {
    }
}

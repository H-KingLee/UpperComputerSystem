﻿using DataLib.UserEnum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SQLite;

namespace DataLib
{
    public class SQLUser
    {
        private static string DBPath = AppDomain.CurrentDomain.BaseDirectory + "\\DB\\" + "\\";
        private static string DBfile = AppDomain.CurrentDomain.BaseDirectory + "\\DB\\" + "\\" + "UserManage.db";

        /// <summary>
        /// 创建表
        /// </summary>
        public  static void CreateTables()
        {
            if (!File.Exists(DBfile))
            {
                //创建文件
                Directory.CreateDirectory(DBPath);
                //创建用户数据表
                using (var conn = new SQLiteConnection($"Data Source={DBfile};Version=3;"))
                {
                    conn.Open();
                    var cmd = conn.CreateCommand();
                    cmd.CommandText = @"
                    CREATE TABLE IF NOT EXISTS Users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        UserName TEXT NOT NULL UNIQUE,
                        Password_Hash TEXT NOT NULL,
                        Role INTEGER NOT NULL,
                        Permission INTEGER NOT NULL
                    )";
                    cmd.ExecuteNonQuery();
                    InsertUser("admin", "123456789", 1, 1);
                    InsertUser("Engineer", "123456", 2, 1);
                    InsertUser("Operator", "123456", 3, 2);
                    InsertUser("Visitor", "123456", 4, 3);
                }

            }
        }
        /// <summary>
        /// 密码加密
        /// </summary>
        /// <param name="password"></param>
        /// <returns></returns>
        static string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(hashedBytes);
            }
        }
        /// <summary>
        /// 插入用户数据
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <param name="role"></param>
        /// <param name="permission"></param>
        /// <param name="resource"></param>
        public static void InsertUser(string username, string password, int role, int permission)
        {
            var hashedPassword = HashPassword(password); // 哈希密码
            using (var conn = new SQLiteConnection($"Data Source={DBfile};Version=3;"))
            {
                conn.Open();
                var insertQuery = "INSERT INTO Users (UserName, Password_Hash, Role,Permission) VALUES (@UserName, @Password_Hash, @Role,@Permission)";
                using (var cmd = new SQLiteCommand(insertQuery, conn))
                {
                    cmd.Parameters.AddWithValue("@UserName", username);
                    cmd.Parameters.AddWithValue("@Password_Hash", hashedPassword);
                    cmd.Parameters.AddWithValue("@Role", role);
                    cmd.Parameters.AddWithValue("@Permission", permission);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        /// <summary>
        /// 用户校验
        /// </summary>
        /// <param name="username"></param>
        /// <param name="userpassword"></param>
        /// <param name="userrole"></param>
        /// <param name="userpermission"></param>
        /// <param name="userresource"></param>
        /// <param name="errorMsg"></param>
        /// <returns></returns>
        public static bool VerifyUser(string username, string userpassword, out RoleEnum userrole, out PermissionEnum userpermission, out string errorMsg)
        {
            bool result = false;
            userrole = RoleEnum.None;
            userpermission = PermissionEnum.None;
            errorMsg = string.Empty;
            var hashedInputPassword = HashPassword(userpassword); // 哈希输入的密码
            try
            {
                using (var conn = new SQLiteConnection($"Data Source={DBfile};Version=3;"))
                {
                    conn.Open();
                    var selectQuery = "SELECT Password_Hash,Role,Permission FROM Users WHERE UserName = @Username";
                    using (var cmd = new SQLiteCommand(selectQuery, conn))
                    {
                        cmd.Parameters.AddWithValue("@Username", username);
                        var reader = cmd.ExecuteReader();
                        if (reader.Read())
                        {
                            //string strstr = reader.GetString(1); // 获取存储的哈希值
                            string storedPasswordHash = reader.GetString(0); // 获取存储的哈希值
                            userrole = (RoleEnum)reader.GetInt32(1);
                            userpermission = (PermissionEnum)reader.GetInt32(2);
                            if (storedPasswordHash == hashedInputPassword)// 比较哈希值是否匹配
                            {
                                result = true;
                            }
                            else
                            {
                                errorMsg = "密码错误！";
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                errorMsg = ex.Message + ex.StackTrace;

            }
            return result; // 用户名不存在或密码不匹配的情况返回false
        }

    }
}

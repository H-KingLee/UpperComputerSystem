﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLib.UserEnum
{
    /// <summary>
    /// ⻆⾊、⾝份或职责枚举
    /// </summary>
    [Description("⻆⾊枚举")]

    public enum RoleEnum
    {
        None = 0,
        [Description("管理员")]
        Administrator = 1,
        [Description("工程师")]
        Engineer = 2,
        [Description("操作员")]
        Operator = 3,
        [Description("访客")]
        Visitor = 4
    }
}

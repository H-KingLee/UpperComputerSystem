﻿namespace CommunicationDriver.Modbus
{
    internal class ModbusRTU
    {
    }
}

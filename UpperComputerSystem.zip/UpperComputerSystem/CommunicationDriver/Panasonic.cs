﻿namespace CommunicationDriver
{
    internal class Panasonic
    {
    }
}

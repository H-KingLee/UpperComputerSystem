﻿//=================================================================================
//功    能：log
//命名空间：logMessageclass
//类    名：logMessage
//使用方法：
///     1引用using logMessageclass;
///     2在需要记录的位置放置logMessage.Message("获取屏幕工作区的大小错误！");
//=================================================================================
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic.Logging;

namespace logMessageclass
{
    class logMessage
    {

        public static void Message(string logMessage)
        {
            //获取当前项目的基目录  E:\hzrvs\ConsoleApplication1\ConsoleApplication1\bin\Debug\
            string path = AppDomain.CurrentDomain.BaseDirectory;
            path = path + "\\logs\\";
            var  logname = " log"+DateTime.Now.Date.ToString("yyyy-MM-dd")+ " .log";
            //检查这个路径存在吗，不存在就创建
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            string logfile= path +logname;
            //向指定的文件操作，如果文件存在就追加，不存在就新建
            StreamWriter writer = new StreamWriter(logfile, true, System.Text.Encoding.UTF8);
            //在文件里写一行日期+信息
            writer.WriteLine(DateTime.Now.ToString("HH:mm:ss:ff")+ "——"+ logMessage);
            //关闭写文件的流
            writer.Close();
        }
        public static string printfile()
        {
            //获取当前项目的基目录  E:\hzrvs\ConsoleApplication1\ConsoleApplication1\bin\Debug\
            string path = AppDomain.CurrentDomain.BaseDirectory;
            ////移除某个位置的后几个字符，我这里的意思是移除lenth-1 位置的后一个字符 E:\hzrvs\ConsoleApplication1\ConsoleApplication1\bin\Debug
            //path = path.Remove(path.Length - 1, 1);
            ////返回一个新字符串，其中当前实例中出现的所有指定字符串都替换为另一个指定的字符串
            ////将/替换为\\  E:\hzrvs\ConsoleApplication1\ConsoleApplication1\bin\Debug
            //path = path.Replace("/", "\\");
            ////截取字符串，截取从0到最后一个\\出现的位置的字符串  E:\hzrvs\ConsoleApplication1\ConsoleApplication1\bin
            //path = path.Substring(0, path.LastIndexOf("\\"));
            //拼串，拼出自己想要存放的位置的路径   E:\hzrvs\ConsoleApplication1\ConsoleApplication1\bin\logs\11-18\
            //path = path + "\\logs\\" + DateTime.Now.Date.ToString("yyyy-MM-dd") + "\\";
            path = path + "\\logs\\";

            var logname = " log" + DateTime.Now.Date.ToString("yyyy-MM-dd") + " .log";
           var  Filename = path + logname;

            string text = File.ReadAllText(@Filename);

            //string[] lines = File.ReadAllLines(Filename);
            return text;

        }

        



    }

}




